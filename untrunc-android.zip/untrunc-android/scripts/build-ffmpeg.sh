#!/usr/bin/env bash
# Baixa e compila o FFmpeg (so o necessario pro untrunc) como bibliotecas
# estaticas para o NDK do Android.
#
# Uso: build-ffmpeg.sh <raiz-do-projeto> <api-level> <ffmpeg-version> <abi> [<abi> ...]
# Saida: <raiz>/ffmpeg-build/<abi>/{include,lib}
set -euo pipefail

ROOT="$1"; API="$2"; FF_VER="$3"; shift 3
ABIS=("$@")
OUT="$ROOT/ffmpeg-build"
SRC="$OUT/src/ffmpeg-$FF_VER"
mkdir -p "$OUT/src"

# ---------- localizar o NDK ----------
find_ndk() {
  for v in "${ANDROID_NDK_HOME:-}" "${ANDROID_NDK_ROOT:-}" "${ANDROID_NDK:-}"; do
    [ -n "$v" ] && [ -d "$v/toolchains/llvm" ] && { echo "$v"; return; }
  done
  local sdk="${ANDROID_HOME:-${ANDROID_SDK_ROOT:-}}"
  if [ -z "$sdk" ] && [ -f "$ROOT/local.properties" ]; then
    sdk=$(sed -n 's/^sdk.dir=//p' "$ROOT/local.properties" | head -1)
  fi
  if [ -n "$sdk" ]; then
    if [ -n "${NDK_VERSION:-}" ] && [ -d "$sdk/ndk/$NDK_VERSION/toolchains/llvm" ]; then
      echo "$sdk/ndk/$NDK_VERSION"; return
    fi
    local d
    d=$(ls -d "$sdk"/ndk/*/ 2>/dev/null | sort -V | tail -1 || true)
    [ -n "$d" ] && { echo "${d%/}"; return; }
    [ -d "$sdk/ndk-bundle/toolchains/llvm" ] && { echo "$sdk/ndk-bundle"; return; }
  fi
}
NDK="$(find_ndk || true)"
[ -n "$NDK" ] || { echo "ERRO: NDK nao encontrado. Defina ANDROID_NDK_HOME." >&2; exit 1; }
TOOLCHAIN=$(ls -d "$NDK"/toolchains/llvm/prebuilt/*/ | head -1)
TOOLCHAIN="${TOOLCHAIN%/}"
echo ">> NDK: $NDK"
echo ">> toolchain: $TOOLCHAIN"

# ---------- baixar o fonte ----------
if [ ! -f "$SRC/configure" ]; then
  TARBALL="$OUT/src/ffmpeg-$FF_VER.tar.xz"
  if [ ! -s "$TARBALL" ]; then
    echo ">> baixando FFmpeg $FF_VER ..."
    for url in "https://ffmpeg.org/releases/ffmpeg-$FF_VER.tar.xz" \
               "https://www.ffmpeg.org/releases/ffmpeg-$FF_VER.tar.xz" \
               "https://github.com/FFmpeg/FFmpeg/archive/refs/tags/n$FF_VER.tar.gz"; do
      if curl -fL --retry 3 -o "$TARBALL.part" "$url"; then
        mv "$TARBALL.part" "$TARBALL"
        break
      fi
    done
  fi
  [ -s "$TARBALL" ] || { echo "ERRO: nao consegui baixar o FFmpeg." >&2; exit 1; }
  echo ">> extraindo ..."
  mkdir -p "$OUT/src/_x" && rm -rf "$OUT/src/_x"/*
  tar -xf "$TARBALL" -C "$OUT/src/_x"
  rm -rf "$SRC"
  mv "$OUT/src/_x"/* "$SRC"
fi

NJOBS=$(nproc 2>/dev/null || echo 2)

build_abi() {
  local abi="$1" arch cpu triple extra=()
  case "$abi" in
    arm64-v8a)   arch=aarch64; cpu=armv8-a;  triple=aarch64-linux-android ;;
    armeabi-v7a) arch=arm;     cpu=armv7-a;  triple=armv7a-linux-androideabi
                 extra+=(--disable-asm) ;;   # evita problemas de NEON/PIC no 32 bits
    x86_64)      arch=x86_64;  cpu=x86-64;   triple=x86_64-linux-android
                 extra+=(--disable-asm) ;;
    x86)         arch=x86;     cpu=i686;     triple=i686-linux-android
                 extra+=(--disable-asm) ;;
    *) echo "ABI desconhecida: $abi" >&2; return 1 ;;
  esac
  local prefix="$OUT/$abi"
  if [ -f "$prefix/lib/libavcodec.a" ] && [ -f "$prefix/lib/libavformat.a" ] && [ -f "$prefix/lib/libavutil.a" ]; then
    echo ">> $abi: FFmpeg ja compilado, pulando."
    return 0
  fi
  local bdir="$OUT/obj/$abi"
  rm -rf "$bdir"; mkdir -p "$bdir"
  local cc="$TOOLCHAIN/bin/${triple}${API}-clang"
  local cxx="$TOOLCHAIN/bin/${triple}${API}-clang++"
  echo ">> $abi: configurando FFmpeg ..."
  ( cd "$bdir" && "$SRC/configure" \
      --prefix="$prefix" \
      --enable-cross-compile --target-os=android \
      --arch="$arch" --cpu="$cpu" \
      --cc="$cc" --cxx="$cxx" \
      --ar="$TOOLCHAIN/bin/llvm-ar" --nm="$TOOLCHAIN/bin/llvm-nm" \
      --ranlib="$TOOLCHAIN/bin/llvm-ranlib" --strip="$TOOLCHAIN/bin/llvm-strip" \
      --enable-static --disable-shared --enable-pic \
      --disable-programs --disable-doc --disable-debug \
      --disable-everything --enable-decoders --enable-parser=hevc \
      --enable-demuxers --enable-protocol=file --enable-protocol=fd \
      --disable-avdevice --disable-swresample --disable-swscale --disable-avfilter \
      --disable-network --disable-autodetect \
      ${extra[@]+"${extra[@]}"} ) || { echo "---- config.log ----"; tail -40 "$bdir/ffbuild/config.log" || true; return 1; }
  echo ">> $abi: compilando FFmpeg (pode levar varios minutos) ..."
  make -C "$bdir" -j"$NJOBS"
  make -C "$bdir" install
  rm -rf "$bdir"
}

for abi in "${ABIS[@]}"; do build_abi "$abi"; done
echo ">> FFmpeg pronto."
