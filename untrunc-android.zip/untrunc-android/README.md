# Untrunc para Android

Port do [untrunc (fork anthwlock)](https://github.com/anthwlock/untrunc) para Android.
Repara vídeos MP4/MOV/M4V/3GP truncados usando um vídeo bom de referência.

## Como funciona
- O código C++ do untrunc está em `app/src/main/cpp/untrunc/` **praticamente intacto**
  (só 3 pequenos trechos marcados com `[android port]`/`__ANDROID__` em `common.h`, `common.cpp`, `mp4.cpp`
  para aceitar arquivos como `fd:<N>`).
- O `main()` original vira `untrunc_main()` (ver `untrunc_entry.cpp`) e roda num **processo filho** (`fork`)
  via JNI (`untrunc_jni.cpp`), então `exit()`/crash do untrunc nunca derruba o app e a saída chega em tempo real.
- Os arquivos são escolhidos com o seletor do sistema (Storage Access Framework), sem permissões de armazenamento.
  O reparo é gravado no cache do app e depois você escolhe onde salvar (precisa de espaço livre ≈ tamanho do vídeo corrompido).
- O **FFmpeg é baixado e compilado automaticamente** (`scripts/build-ffmpeg.sh`) como lib estática para o NDK,
  só com o que o untrunc precisa (decoders, demuxers, parser hevc, protocolos file/fd).

## Compilar
```
./gradlew assembleDebug
```
A primeira vez baixa o FFmpeg 7.1 e compila (alguns minutos; precisa de `curl`, `tar`, `xz`, `make`).
APK: `app/build/outputs/apk/debug/app-debug.apk`

Para rodar só a parte do FFmpeg: `./gradlew buildFfmpeg`.

### Termux (opções em `gradle.properties`)
- `android.aapt2FromMavenOverride=/data/data/com.termux/files/usr/bin/aapt2`
- `untruncNdkVersion=<pasta em $ANDROID_HOME/ndk/>` (ou exporte `ANDROID_NDK_HOME`)
- `untruncCmakeVersion=<versão do cmake instalada no SDK>` se não for a 3.22.1
- `untruncAbis=arm64-v8a` (padrão); `armeabi-v7a`, `x86_64` também funcionam
- Precisa de `local.properties` com `sdk.dir=...`

## Não testado
Este projeto foi escrito sem acesso a NDK/FFmpeg/Maven no ambiente onde foi gerado,
então **nunca foi compilado**. Se der erro no build, mande o log que eu corrijo.

## Licença
GPL v2+ (mesma do untrunc). Veja `COPYING`.
