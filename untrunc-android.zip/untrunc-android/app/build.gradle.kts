plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

val abis = (findProperty("untruncAbis") as String? ?: "arm64-v8a")
    .split(",").map { it.trim() }.filter { it.isNotEmpty() }
val ffmpegVersion = (findProperty("untruncFfmpegVersion") as String?) ?: "7.1"
val minApi = 24

android {
    namespace = "com.untrunc.android"
    compileSdk = 34

    (findProperty("untruncNdkVersion") as String?)?.let { ndkVersion = it }

    defaultConfig {
        applicationId = "com.untrunc.android"
        minSdk = minApi
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"

        ndk { abiFilters += abis }

        externalNativeBuild {
            cmake {
                arguments += listOf(
                    "-DANDROID_STL=c++_shared",
                    "-DFFMPEG_BUILD_DIR=${rootDir}/ffmpeg-build"
                )
                cppFlags += listOf("-std=c++17")
            }
        }
    }

    externalNativeBuild {
        cmake {
            path = file("src/main/cpp/CMakeLists.txt")
            (findProperty("untruncCmakeVersion") as String?)?.let { version = it }
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }

    packaging {
        jniLibs { useLegacyPackaging = false }
    }
}

// ---- Compila o FFmpeg para o NDK antes de qualquer build nativo ----
val buildFfmpeg = tasks.register<Exec>("buildFfmpeg") {
    group = "untrunc"
    description = "Baixa e compila o FFmpeg (estatico) para as ABIs configuradas"
    val script = rootProject.file("scripts/build-ffmpeg.sh")
    inputs.file(script)
    inputs.property("abis", abis)
    inputs.property("ffmpegVersion", ffmpegVersion)
    outputs.dir(rootProject.file("ffmpeg-build"))
    outputs.upToDateWhen {
        abis.all { abi ->
            listOf("avcodec", "avformat", "avutil").all {
                rootProject.file("ffmpeg-build/$abi/lib/lib$it.a").exists()
            }
        }
    }
    doFirst {
        try {
            // o script tambem procura o NDK sozinho; isto so ajuda quando o AGP ja o resolveu
            val dir = project.extensions.getByType(
                com.android.build.api.variant.AndroidComponentsExtension::class.java
            ).sdkComponents.ndkDirectory.get().asFile
            if (System.getenv("ANDROID_NDK_HOME").isNullOrEmpty()) {
                environment("ANDROID_NDK_HOME", dir.absolutePath)
            }
        } catch (_: Throwable) { }
        (findProperty("untruncNdkVersion") as String?)?.let { environment("NDK_VERSION", it) }
    }
    commandLine(
        listOf("bash", script.absolutePath, rootDir.absolutePath, minApi.toString(), ffmpegVersion) + abis
    )
}

tasks.named("preBuild") { dependsOn(buildFfmpeg) }
