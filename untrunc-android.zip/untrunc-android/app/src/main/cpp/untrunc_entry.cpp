// Reaproveita o main() original do untrunc sem modificar o codigo upstream.
#define main untrunc_main
#include "untrunc/main.cpp"
#undef main
