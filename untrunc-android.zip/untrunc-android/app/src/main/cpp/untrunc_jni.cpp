// Ponte JNI: roda o untrunc num processo filho (fork) para que
//  - exit() / abort() / crashes do untrunc nunca derrubem o app;
//  - o estado global do untrunc (g_*) comece limpo a cada execucao;
//  - a saida (stdout/stderr) possa ser lida em tempo real por um pipe.
#include <jni.h>

#include <atomic>
#include <cerrno>
#include <csignal>
#include <cstdio>
#include <cstring>
#include <exception>
#include <string>
#include <vector>

#include <fcntl.h>
#include <sys/wait.h>
#include <unistd.h>

int untrunc_main(int argc, char** argv);  // C++ linkage (main renomeado em untrunc_entry.cpp)


static std::atomic<pid_t> g_child{0};

static void child_run(int wfd, std::vector<std::string>& args) {
	// stdin -> /dev/null (untrunc roda com -n, mas por seguranca)
	int dn = open("/dev/null", O_RDONLY);
	if (dn >= 0) { dup2(dn, 0); if (dn > 2) close(dn); }
	dup2(wfd, 1);
	dup2(wfd, 2);
	if (wfd > 2) close(wfd);
	setvbuf(stdout, nullptr, _IONBF, 0);
	setvbuf(stderr, nullptr, _IONBF, 0);

	std::vector<char*> argv;
	for (auto& s : args) argv.push_back(const_cast<char*>(s.c_str()));
	argv.push_back(nullptr);

	int rc = 1;
	try {
		rc = untrunc_main((int)args.size(), argv.data());
	} catch (const char* e) {
		fprintf(stderr, "Error: %s\n", e); rc = 1;
	} catch (const std::string& e) {
		fprintf(stderr, "Error: %s\n", e.c_str()); rc = 1;
	} catch (const std::exception& e) {
		fprintf(stderr, "Error: %s\n", e.what()); rc = 1;
	} catch (...) {
		fprintf(stderr, "Error: unknown exception\n"); rc = 1;
	}
	fflush(stdout); fflush(stderr);
	_exit(rc);
}

// Mantem so ASCII imprimivel (NewStringUTF aborta com UTF-8 invalido).
static std::string sanitize(const std::string& s) {
	std::string r;
	r.reserve(s.size());
	for (unsigned char c : s) {
		if (c == '\t' || (c >= 0x20 && c < 0x7f)) r.push_back((char)c);
		else if (c >= 0x80) r.push_back('?');
	}
	return r;
}

extern "C" JNIEXPORT jint JNICALL
Java_com_untrunc_android_UntruncNative_run(JNIEnv* env, jclass, jobjectArray jargs, jobject listener) {
	std::vector<std::string> args;
	args.push_back("untrunc");
	jsize n = env->GetArrayLength(jargs);
	for (jsize i = 0; i < n; i++) {
		auto js = (jstring)env->GetObjectArrayElement(jargs, i);
		const char* c = env->GetStringUTFChars(js, nullptr);
		args.push_back(c);
		env->ReleaseStringUTFChars(js, c);
		env->DeleteLocalRef(js);
	}

	jclass lcls = env->GetObjectClass(listener);
	jmethodID onLine = env->GetMethodID(lcls, "onLine", "(Ljava/lang/String;)V");
	if (!onLine) return -100;

	int fds[2];
	if (pipe(fds) != 0) return -101;

	pid_t pid = fork();
	if (pid < 0) {
		close(fds[0]); close(fds[1]);
		return -102;
	}
	if (pid == 0) {
		close(fds[0]);
		child_run(fds[1], args);  // nunca retorna
	}
	close(fds[1]);
	g_child.store(pid);

	std::string line;
	auto flush_line = [&]() {
		if (line.empty()) return;
		std::string s = sanitize(line);
		line.clear();
		if (s.empty()) return;
		jstring js = env->NewStringUTF(s.c_str());
		env->CallVoidMethod(listener, onLine, js);
		env->DeleteLocalRef(js);
		if (env->ExceptionCheck()) env->ExceptionClear();
	};

	char buf[4096];
	for (;;) {
		ssize_t r = read(fds[0], buf, sizeof buf);
		if (r < 0) { if (errno == EINTR) continue; break; }
		if (r == 0) break;
		for (ssize_t i = 0; i < r; i++) {
			if (buf[i] == '\n' || buf[i] == '\r') flush_line();
			else line.push_back(buf[i]);
			if (line.size() > 2000) flush_line();
		}
	}
	flush_line();
	close(fds[0]);

	int status = 0;
	while (waitpid(pid, &status, 0) < 0 && errno == EINTR) {}
	g_child.store(0);

	if (WIFEXITED(status)) return WEXITSTATUS(status);
	if (WIFSIGNALED(status)) return -WTERMSIG(status);
	return -103;
}

extern "C" JNIEXPORT void JNICALL
Java_com_untrunc_android_UntruncNative_cancel(JNIEnv*, jclass) {
	pid_t p = g_child.load();
	if (p > 0) kill(p, SIGKILL);
}

extern "C" JNIEXPORT jstring JNICALL
Java_com_untrunc_android_UntruncNative_version(JNIEnv* env, jclass) {
	return env->NewStringUTF("untrunc (anthwlock fork) android-1.0");
}
