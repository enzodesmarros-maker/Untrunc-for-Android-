package com.untrunc.android

import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Bundle
import android.os.ParcelFileDescriptor
import android.os.SystemClock
import android.provider.OpenableColumns
import android.view.LayoutInflater
import android.view.View
import android.view.WindowManager
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {

    private companion object {
        const val REQ_OK = 1
        const val REQ_BAD = 2
        const val REQ_SAVE = 3
        val PROGRESS_RE = Regex("""^\s*(\d+(?:\.\d+)?)%""")
        const val MAX_LOG_CHARS = 60_000
        const val PREFS = "untrunc"
    }

    private var okUri: Uri? = null
    private var badUri: Uri? = null
    private var okName = ""
    private var badName = ""
    private var resultFile: File? = null
    private var lastSavedUri: Uri? = null
    private var running = false
    private var startTime = 0L
    private val log = StringBuilder()

    private val prefs by lazy { getSharedPreferences(PREFS, MODE_PRIVATE) }

    private fun <T : View> v(id: Int): T = findViewById(id)

    private lateinit var scroll: ScrollView
    private lateinit var pageRepair: View
    private lateinit var pageHistory: View
    private lateinit var navRepairIcon: ImageView
    private lateinit var navRepairText: TextView
    private lateinit var navHistoryIcon: ImageView
    private lateinit var navHistoryText: TextView

    private lateinit var cardOk: View
    private lateinit var cardBad: View
    private lateinit var thumbOk: ImageView
    private lateinit var thumbBad: ImageView
    private lateinit var nameOk: TextView
    private lateinit var nameBad: TextView
    private lateinit var metaOk: TextView
    private lateinit var metaBad: TextView

    private lateinit var advBody: View
    private lateinit var advChevron: View
    private lateinit var stepRow: View
    private lateinit var edStep: EditText
    private lateinit var swSkip: Switch
    private lateinit var swKeep: Switch
    private lateinit var swDyn: Switch
    private lateinit var swStretch: Switch
    private lateinit var swNoCtts: Switch
    private lateinit var swSm: Switch

    private lateinit var btnRepair: TextView
    private lateinit var btnCancel: TextView
    private lateinit var cardProgress: View
    private lateinit var txtProgTitle: TextView
    private lateinit var txtPct: TextView
    private lateinit var progress: ProgressBar
    private lateinit var txtEta: TextView
    private lateinit var btnLog: TextView
    private lateinit var txtLog: TextView
    private lateinit var cardResult: View
    private lateinit var txtResultTitle: TextView
    private lateinit var txtResultSub: TextView
    private lateinit var btnSave: TextView
    private lateinit var btnShareResult: TextView

    private lateinit var statRepaired: TextView
    private lateinit var statRate: TextView
    private lateinit var historyList: LinearLayout
    private lateinit var txtHistoryEmpty: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        scroll = v(R.id.scroll)
        pageRepair = v(R.id.pageRepair)
        pageHistory = v(R.id.pageHistory)
        navRepairIcon = v(R.id.navRepairIcon)
        navRepairText = v(R.id.navRepairText)
        navHistoryIcon = v(R.id.navHistoryIcon)
        navHistoryText = v(R.id.navHistoryText)

        cardOk = v(R.id.cardOk)
        cardBad = v(R.id.cardBad)
        thumbOk = v(R.id.thumbOk)
        thumbBad = v(R.id.thumbBad)
        nameOk = v(R.id.nameOk)
        nameBad = v(R.id.nameBad)
        metaOk = v(R.id.metaOk)
        metaBad = v(R.id.metaBad)
        thumbOk.clipToOutline = true
        thumbBad.clipToOutline = true

        advBody = v(R.id.advBody)
        advChevron = v(R.id.advChevron)
        stepRow = v(R.id.stepRow)
        edStep = v(R.id.edStep)
        swSkip = v(R.id.swSkip)
        swKeep = v(R.id.swKeep)
        swDyn = v(R.id.swDyn)
        swStretch = v(R.id.swStretch)
        swNoCtts = v(R.id.swNoCtts)
        swSm = v(R.id.swSm)

        btnRepair = v(R.id.btnRepair)
        btnCancel = v(R.id.btnCancel)
        cardProgress = v(R.id.cardProgress)
        txtProgTitle = v(R.id.txtProgTitle)
        txtPct = v(R.id.txtPct)
        progress = v(R.id.progress)
        txtEta = v(R.id.txtEta)
        btnLog = v(R.id.btnLog)
        txtLog = v(R.id.txtLog)
        cardResult = v(R.id.cardResult)
        txtResultTitle = v(R.id.txtResultTitle)
        txtResultSub = v(R.id.txtResultSub)
        btnSave = v(R.id.btnSave)
        btnShareResult = v(R.id.btnShareResult)

        statRepaired = v(R.id.statRepaired)
        statRate = v(R.id.statRate)
        historyList = v(R.id.historyList)
        txtHistoryEmpty = v(R.id.txtHistoryEmpty)

        cardOk.setOnClickListener { if (!running) pick(REQ_OK) }
        cardBad.setOnClickListener { if (!running) pick(REQ_BAD) }
        v<View>(R.id.advHeader).setOnClickListener { toggleAdvanced() }
        swSkip.setOnCheckedChangeListener { _, checked ->
            stepRow.visibility = if (checked) View.VISIBLE else View.GONE
        }
        btnRepair.setOnClickListener { if (canRepair()) startRepair() }
        btnCancel.setOnClickListener { UntruncNative.cancel() }
        btnLog.setOnClickListener {
            val show = txtLog.visibility != View.VISIBLE
            txtLog.visibility = if (show) View.VISIBLE else View.GONE
            btnLog.text = if (show) "Ocultar detalhes ▴" else "Ver detalhes ▾"
        }
        btnSave.setOnClickListener { launchSavePicker() }
        btnShareResult.setOnClickListener { lastSavedUri?.let { share(it) } }
        v<View>(R.id.navRepair).setOnClickListener { showTab(true) }
        v<View>(R.id.navHistory).setOnClickListener { showTab(false) }
        v<View>(R.id.btnClearHistory).setOnClickListener {
            prefs.edit().remove("history").apply()
            refreshHistory()
        }

        restoreOptions()
        showTab(true)
        refreshStats()
        refreshHistory()
        updateRepairButton()

        // Limpa resíduos de execuções anteriores
        File(cacheDir, "work").deleteRecursively()
    }

    // ---------------------------------------------------------------- UI helpers

    private fun showTab(repair: Boolean) {
        pageRepair.visibility = if (repair) View.VISIBLE else View.GONE
        pageHistory.visibility = if (repair) View.GONE else View.VISIBLE
        val on = 0xFF2DD4BF.toInt()
        val off = 0xFF8B97A8.toInt()
        navRepairIcon.setColorFilter(if (repair) on else off)
        navRepairText.setTextColor(if (repair) on else off)
        navHistoryIcon.setColorFilter(if (repair) off else on)
        navHistoryText.setTextColor(if (repair) off else on)
        if (!repair) refreshHistory()
        scroll.post { scroll.scrollTo(0, 0) }
    }

    private fun toggleAdvanced() {
        val open = advBody.visibility != View.VISIBLE
        advBody.visibility = if (open) View.VISIBLE else View.GONE
        advChevron.rotation = if (open) 180f else 0f
    }

    private fun canRepair() = !running && okUri != null && badUri != null

    private fun updateRepairButton() {
        btnRepair.alpha = if (canRepair()) 1f else 0.4f
    }

    private fun fmtSize(b: Long): String = when {
        b >= (1L shl 30) -> "%.2f GB".format(b / (1L shl 30).toDouble())
        b >= (1L shl 20) -> "%.1f MB".format(b / (1L shl 20).toDouble())
        b >= 1024 -> "%d KB".format(b / 1024)
        else -> "$b B"
    }

    private fun fmtDuration(ms: Long): String {
        val s = ms / 1000
        val h = s / 3600
        val m = (s % 3600) / 60
        val sec = s % 60
        return if (h > 0) "%d:%02d:%02d".format(h, m, sec) else "%02d:%02d".format(m, sec)
    }

    private fun fmtEta(seconds: Long): String {
        val s = seconds.coerceAtLeast(0)
        return "%02d:%02d".format(s / 60, s % 60)
    }

    private fun appendLog(line: String) {
        log.append(line).append('\n')
        if (log.length > MAX_LOG_CHARS) log.delete(0, log.length - MAX_LOG_CHARS / 2)
        txtLog.text = log
    }

    // ---------------------------------------------------------------- Seleção de arquivos

    private fun pick(req: Int) {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
            putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("video/*", "application/octet-stream"))
        }
        @Suppress("DEPRECATION")
        startActivityForResult(i, req)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_SAVE) {
            val uri = data?.data
            if (resultCode == RESULT_OK && uri != null) saveResult(uri)
            else txtResultSub.text = "Salvamento cancelado. Toque em \"Salvar vídeo\" para escolher o local."
            return
        }
        if (resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        when (requestCode) {
            REQ_OK -> {
                okUri = uri
                okName = displayName(uri)
                nameOk.text = okName
                loadInfo(uri, thumbOk, metaOk)
            }
            REQ_BAD -> {
                badUri = uri
                badName = displayName(uri)
                nameBad.text = badName
                loadInfo(uri, thumbBad, metaBad)
            }
        }
        updateRepairButton()
    }

    private fun displayName(uri: Uri): String {
        try {
            contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
                if (it.moveToFirst()) return it.getString(0) ?: "video"
            }
        } catch (_: Exception) { }
        return uri.lastPathSegment ?: "video"
    }

    private fun fileSize(uri: Uri): Long {
        try {
            contentResolver.query(uri, arrayOf(OpenableColumns.SIZE), null, null, null)?.use {
                if (it.moveToFirst() && !it.isNull(0)) return it.getLong(0)
            }
        } catch (_: Exception) { }
        return -1L
    }

    /** Carrega miniatura, duração e tamanho (um vídeo corrompido pode não ter prévia). */
    private fun loadInfo(uri: Uri, thumb: ImageView, meta: TextView) {
        val size = fileSize(uri)
        val sizeTxt = if (size >= 0) fmtSize(size) else "?"
        meta.text = sizeTxt
        thumb.setImageDrawable(null)
        Thread {
            var bmp: Bitmap? = null
            var dur = -1L
            val mmr = MediaMetadataRetriever()
            try {
                mmr.setDataSource(this, uri)
                dur = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: -1L
                bmp = mmr.getFrameAtTime(0)
            } catch (_: Throwable) {
            } finally {
                try { mmr.release() } catch (_: Throwable) { }
            }
            runOnUiThread {
                if (bmp != null) thumb.setImageBitmap(bmp)
                meta.text = when {
                    dur > 0 -> "${fmtDuration(dur)} • $sizeTxt"
                    bmp == null -> "$sizeTxt • sem prévia (normal se estiver corrompido)"
                    else -> sizeTxt
                }
            }
        }.start()
    }

    // ---------------------------------------------------------------- Opções

    private fun restoreOptions() {
        swSkip.isChecked = prefs.getBoolean("o_skip", false)
        swKeep.isChecked = prefs.getBoolean("o_keep", false)
        swDyn.isChecked = prefs.getBoolean("o_dyn", false)
        swStretch.isChecked = prefs.getBoolean("o_stretch", false)
        swNoCtts.isChecked = prefs.getBoolean("o_noctts", false)
        swSm.isChecked = prefs.getBoolean("o_sm", false)
        edStep.setText(prefs.getString("o_step", ""))
        stepRow.visibility = if (swSkip.isChecked) View.VISIBLE else View.GONE
    }

    private fun saveOptions() {
        prefs.edit()
            .putBoolean("o_skip", swSkip.isChecked)
            .putBoolean("o_keep", swKeep.isChecked)
            .putBoolean("o_dyn", swDyn.isChecked)
            .putBoolean("o_stretch", swStretch.isChecked)
            .putBoolean("o_noctts", swNoCtts.isChecked)
            .putBoolean("o_sm", swSm.isChecked)
            .putString("o_step", edStep.text.toString())
            .apply()
    }

    // ---------------------------------------------------------------- Reparo

    private fun setRunning(r: Boolean) {
        running = r
        btnCancel.visibility = if (r) View.VISIBLE else View.GONE
        swSkip.isEnabled = !r
        swKeep.isEnabled = !r
        swDyn.isEnabled = !r
        swStretch.isEnabled = !r
        swNoCtts.isEnabled = !r
        swSm.isEnabled = !r
        edStep.isEnabled = !r
        updateRepairButton()
        if (r) window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        else window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    }

    private fun bumpAttempts() {
        prefs.edit().putInt("attempts", prefs.getInt("attempts", 0) + 1).apply()
        refreshStats()
    }

    private fun startRepair() {
        val ok = okUri ?: return
        val bad = badUri ?: return
        if (running) return
        saveOptions()

        log.setLength(0)
        txtLog.text = ""
        progress.progress = 0
        txtPct.text = "0%"
        txtEta.text = "Mantenha o app aberto"
        txtProgTitle.text = "Reparando: $badName"
        cardProgress.visibility = View.VISIBLE
        cardResult.visibility = View.GONE
        btnSave.visibility = View.GONE
        btnShareResult.visibility = View.GONE
        resultFile = null
        lastSavedUri = null

        val workDir = File(cacheDir, "work").apply { deleteRecursively(); mkdirs() }
        val out = File(workDir, "fixed.mp4")

        val pfdOk: ParcelFileDescriptor?
        val pfdBad: ParcelFileDescriptor?
        try {
            pfdOk = contentResolver.openFileDescriptor(ok, "r")
            pfdBad = contentResolver.openFileDescriptor(bad, "r")
        } catch (e: Exception) {
            showFailure("Não consegui abrir os arquivos: ${e.message}")
            return
        }
        if (pfdOk == null || pfdBad == null) {
            pfdOk?.close(); pfdBad?.close()
            showFailure("Não consegui abrir os arquivos.")
            return
        }

        // O reparo gera um arquivo do tamanho (aprox.) do vídeo corrompido no cache do app.
        val needed = pfdBad.statSize
        if (needed > 0 && workDir.usableSpace < needed + (64L shl 20)) {
            pfdOk.close(); pfdBad.close()
            showFailure("Espaço insuficiente: preciso de ~${needed shr 20} MB livres no armazenamento interno.")
            return
        }

        val args = ArrayList<String>()
        args += "-n"                                   // sem perguntas interativas
        if (swSkip.isChecked) {
            args += "-s"
            val step = edStep.text.toString().trim().toIntOrNull()
            if (step != null && step > 0) { args += "-st"; args += step.toString() }
        }
        if (swKeep.isChecked) args += "-k"
        if (swDyn.isChecked) args += "-dyn"
        if (swStretch.isChecked) args += "-sv"
        if (swNoCtts.isChecked) args += "-noctts"
        if (swSm.isChecked) args += "-sm"
        args += listOf("-dst", out.absolutePath)
        args += "fd:${pfdOk.fd}"                       // vídeo de referência
        args += "fd:${pfdBad.fd}"                      // vídeo corrompido

        bumpAttempts()
        setRunning(true)
        startTime = SystemClock.elapsedRealtime()

        val listener = object : UntruncNative.Listener {
            override fun onLine(line: String) {
                val m = PROGRESS_RE.find(line)
                runOnUiThread {
                    if (m != null) {
                        val pct = m.groupValues[1].toDoubleOrNull() ?: 0.0
                        progress.progress = (pct * 10).toInt().coerceIn(0, 1000)
                        txtPct.text = "${"%.1f".format(pct)}%"
                        if (pct >= 1.0) {
                            val el = (SystemClock.elapsedRealtime() - startTime) / 1000.0
                            val eta = (el * (100.0 - pct) / pct).toLong()
                            txtEta.text = "Tempo restante: ~${fmtEta(eta)}"
                        }
                    } else {
                        appendLog(line)
                    }
                }
            }
        }

        Thread {
            val rc = try {
                UntruncNative.run(args.toTypedArray(), listener)
            } catch (t: Throwable) {
                runOnUiThread { appendLog("Erro: $t") }
                -999
            } finally {
                try { pfdOk.close() } catch (_: IOException) { }
                try { pfdBad.close() } catch (_: IOException) { }
            }
            runOnUiThread { onFinished(rc, out) }
        }.start()
    }

    private fun showFailure(msg: String) {
        cardResult.visibility = View.VISIBLE
        txtResultTitle.text = "Não foi possível reparar"
        txtResultTitle.setTextColor(0xFFF87171.toInt())
        txtResultSub.text = msg
        btnSave.visibility = View.GONE
        btnShareResult.visibility = View.GONE
    }

    private fun onFinished(rc: Int, out: File) {
        setRunning(false)
        if (rc == 0 && out.exists() && out.length() > 0) {
            progress.progress = 1000
            txtPct.text = "100%"
            txtEta.text = "Concluído"
            resultFile = out
            cardResult.visibility = View.VISIBLE
            txtResultTitle.text = "Reparado!"
            txtResultTitle.setTextColor(0xFF34D399.toInt())
            txtResultSub.text = "Vídeo gerado (${fmtSize(out.length())}). Escolha onde salvar."
            btnSave.visibility = View.VISIBLE
            launchSavePicker()
        } else {
            val why = when {
                rc < 0 -> "o processo foi encerrado (código $rc)"
                rc != 0 -> "o untrunc terminou com erro (código $rc)"
                else -> "nenhum arquivo foi gerado"
            }
            showFailure("Falhou: $why. Veja os detalhes acima e tente ativar \"Pular bytes desconhecidos\".")
            File(cacheDir, "work").deleteRecursively()
        }
    }

    // ---------------------------------------------------------------- Salvar / compartilhar

    private fun launchSavePicker() {
        if (resultFile == null) return
        val base = badName.substringBeforeLast('.', badName)
        val ext = okName.substringAfterLast('.', "mp4")
        val i = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "video/*"
            putExtra(Intent.EXTRA_TITLE, "${base}_fixed.$ext")
            addFlags(
                Intent.FLAG_GRANT_READ_URI_PERMISSION or
                    Intent.FLAG_GRANT_WRITE_URI_PERMISSION or
                    Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION
            )
        }
        @Suppress("DEPRECATION")
        startActivityForResult(i, REQ_SAVE)
    }

    private fun saveResult(dest: Uri) {
        val src = resultFile ?: return
        txtResultSub.text = "Salvando…"
        btnSave.visibility = View.GONE
        Thread {
            var err: String? = null
            try {
                contentResolver.openOutputStream(dest, "wt")!!.use { os ->
                    src.inputStream().use { it.copyTo(os, 1 shl 20) }
                }
            } catch (e: Exception) {
                err = e.message ?: e.toString()
            }
            val size = src.length()
            runOnUiThread {
                if (err == null) {
                    try {
                        contentResolver.takePersistableUriPermission(
                            dest,
                            Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                        )
                    } catch (_: Exception) { }
                    lastSavedUri = dest
                    txtResultSub.text = "Salvo com sucesso (${fmtSize(size)})."
                    btnShareResult.visibility = View.VISIBLE
                    Toast.makeText(this, "Vídeo salvo!", Toast.LENGTH_LONG).show()
                    addHistory(displayName(dest), dest, size)
                    File(cacheDir, "work").deleteRecursively()
                    resultFile = null
                    prefs.edit().putInt("successes", prefs.getInt("successes", 0) + 1).apply()
                    refreshStats()
                } else {
                    txtResultSub.text = "Erro ao salvar: $err"
                    btnSave.visibility = View.VISIBLE
                }
            }
        }.start()
    }

    private fun share(uri: Uri) {
        try {
            val i = Intent(Intent.ACTION_SEND).apply {
                type = "video/*"
                putExtra(Intent.EXTRA_STREAM, uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            startActivity(Intent.createChooser(i, "Compartilhar vídeo"))
        } catch (e: Exception) {
            Toast.makeText(this, "Não foi possível compartilhar: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun play(uri: Uri) {
        try {
            val i = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(uri, "video/*")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            startActivity(i)
        } catch (e: Exception) {
            Toast.makeText(this, "Não foi possível abrir: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    // ---------------------------------------------------------------- Histórico e estatísticas

    private fun loadHistory(): JSONArray =
        try { JSONArray(prefs.getString("history", "[]")) } catch (_: Exception) { JSONArray() }

    private fun addHistory(name: String, uri: Uri, size: Long) {
        val old = loadHistory()
        val arr = JSONArray()
        arr.put(JSONObject().put("name", name).put("uri", uri.toString()).put("size", size).put("time", System.currentTimeMillis()))
        for (i in 0 until minOf(old.length(), 49)) arr.put(old.get(i))
        prefs.edit().putString("history", arr.toString()).apply()
        refreshHistory()
    }

    private fun refreshStats() {
        val ok = prefs.getInt("successes", 0)
        val attempts = prefs.getInt("attempts", 0)
        statRepaired.text = ok.toString()
        statRate.text = if (attempts > 0) "${ok * 100 / attempts}%" else "—"
    }

    private fun refreshHistory() {
        historyList.removeAllViews()
        val arr = loadHistory()
        txtHistoryEmpty.visibility = if (arr.length() == 0) View.VISIBLE else View.GONE
        val df = SimpleDateFormat("dd/MM HH:mm", Locale.getDefault())
        val inflater = LayoutInflater.from(this)
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            val uri = Uri.parse(o.optString("uri"))
            val row = inflater.inflate(R.layout.item_history, historyList, false)
            row.findViewById<TextView>(R.id.hName).text = o.optString("name")
            row.findViewById<TextView>(R.id.hMeta).text =
                "${df.format(Date(o.optLong("time")))} • ${fmtSize(o.optLong("size"))}"
            row.findViewById<View>(R.id.hShare).setOnClickListener { share(uri) }
            row.findViewById<View>(R.id.hPlay).setOnClickListener { play(uri) }
            historyList.addView(row)
        }
    }

    override fun onDestroy() {
        if (isFinishing) UntruncNative.cancel()
        super.onDestroy()
    }
}
