package com.untrunc.android

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.ParcelFileDescriptor
import android.provider.OpenableColumns
import android.view.WindowManager
import android.widget.Button
import android.widget.CheckBox
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.io.File
import java.io.IOException

class MainActivity : Activity() {

    private companion object {
        const val REQ_OK = 1
        const val REQ_BAD = 2
        const val REQ_SAVE = 3
        val PROGRESS_RE = Regex("""^\s*(\d+(?:\.\d+)?)%""")
        const val MAX_LOG_CHARS = 60_000
    }

    private var okUri: Uri? = null
    private var badUri: Uri? = null
    private var okName = ""
    private var badName = ""
    private var resultFile: File? = null
    private var running = false

    private val log = StringBuilder()

    private lateinit var btnOk: Button
    private lateinit var btnBad: Button
    private lateinit var btnRepair: Button
    private lateinit var btnCancel: Button
    private lateinit var txtOk: TextView
    private lateinit var txtBad: TextView
    private lateinit var txtStatus: TextView
    private lateinit var txtLog: TextView
    private lateinit var scroll: ScrollView
    private lateinit var progress: ProgressBar
    private lateinit var chkSkip: CheckBox
    private lateinit var chkStretch: CheckBox

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        btnOk = findViewById(R.id.btnOk)
        btnBad = findViewById(R.id.btnBad)
        btnRepair = findViewById(R.id.btnRepair)
        btnCancel = findViewById(R.id.btnCancel)
        txtOk = findViewById(R.id.txtOk)
        txtBad = findViewById(R.id.txtBad)
        txtStatus = findViewById(R.id.txtStatus)
        txtLog = findViewById(R.id.txtLog)
        scroll = findViewById(R.id.scroll)
        progress = findViewById(R.id.progress)
        chkSkip = findViewById(R.id.chkSkip)
        chkStretch = findViewById(R.id.chkStretch)

        btnOk.setOnClickListener { pick(REQ_OK) }
        btnBad.setOnClickListener { pick(REQ_BAD) }
        btnRepair.setOnClickListener { startRepair() }
        btnCancel.setOnClickListener { UntruncNative.cancel() }

        // Limpa resíduos de execuções anteriores
        File(cacheDir, "work").deleteRecursively()
    }

    private fun pick(req: Int) {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
            putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("video/*", "application/octet-stream"))
        }
        @Suppress("DEPRECATION")
        startActivityForResult(i, req)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK) {
            if (requestCode == REQ_SAVE) {
                setStatus("Salvamento cancelado. O vídeo reparado ainda está no cache; toque em Reparar de novo para refazer.")
            }
            return
        }
        val uri = data?.data ?: return
        when (requestCode) {
            REQ_OK -> { okUri = uri; okName = displayName(uri); txtOk.text = okName }
            REQ_BAD -> { badUri = uri; badName = displayName(uri); txtBad.text = badName }
            REQ_SAVE -> { saveResult(uri); return }
        }
        btnRepair.isEnabled = okUri != null && badUri != null && !running
    }

    private fun displayName(uri: Uri): String {
        try {
            contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
                if (it.moveToFirst()) return it.getString(0) ?: "video"
            }
        } catch (_: Exception) { }
        return uri.lastPathSegment ?: "video"
    }

    private fun setStatus(s: String) { txtStatus.text = s }

    private fun appendLog(line: String) {
        log.append(line).append('\n')
        if (log.length > MAX_LOG_CHARS) log.delete(0, log.length - MAX_LOG_CHARS / 2)
        txtLog.text = log
        scroll.post { scroll.fullScroll(ScrollView.FOCUS_DOWN) }
    }

    private fun setRunning(r: Boolean) {
        running = r
        btnOk.isEnabled = !r
        btnBad.isEnabled = !r
        chkSkip.isEnabled = !r
        chkStretch.isEnabled = !r
        btnCancel.isEnabled = r
        btnRepair.isEnabled = !r && okUri != null && badUri != null
        if (r) window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        else window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    }

    private fun startRepair() {
        val ok = okUri ?: return
        val bad = badUri ?: return
        if (running) return

        log.setLength(0)
        txtLog.text = ""
        progress.progress = 0

        val workDir = File(cacheDir, "work").apply { deleteRecursively(); mkdirs() }
        val out = File(workDir, "fixed.mp4")

        val pfdOk: ParcelFileDescriptor?
        val pfdBad: ParcelFileDescriptor?
        try {
            pfdOk = contentResolver.openFileDescriptor(ok, "r")
            pfdBad = contentResolver.openFileDescriptor(bad, "r")
        } catch (e: Exception) {
            setStatus("Não consegui abrir os arquivos: ${e.message}")
            return
        }
        if (pfdOk == null || pfdBad == null) {
            pfdOk?.close(); pfdBad?.close()
            setStatus("Não consegui abrir os arquivos.")
            return
        }

        // O reparo gera um arquivo do tamanho (aprox.) do vídeo corrompido no cache do app.
        val needed = pfdBad.statSize
        if (needed > 0 && workDir.usableSpace < needed + (64L shl 20)) {
            pfdOk.close(); pfdBad.close()
            setStatus("Espaço insuficiente: preciso de ~${needed shr 20} MB livres no armazenamento interno.")
            return
        }

        val args = ArrayList<String>()
        args += "-n"                       // sem perguntas interativas
        if (chkSkip.isChecked) args += "-s"
        if (chkStretch.isChecked) args += "-sv"
        args += listOf("-dst", out.absolutePath)
        args += "fd:${pfdOk.fd}"           // vídeo de referência
        args += "fd:${pfdBad.fd}"          // vídeo corrompido

        setRunning(true)
        setStatus("Reparando… (mantenha o app aberto)")

        val listener = object : UntruncNative.Listener {
            override fun onLine(line: String) {
                val m = PROGRESS_RE.find(line)
                runOnUiThread {
                    if (m != null) {
                        val pct = m.groupValues[1].toDoubleOrNull() ?: 0.0
                        progress.progress = (pct * 10).toInt().coerceIn(0, 1000)
                        setStatus("Reparando… ${"%.1f".format(pct)}%")
                    } else {
                        appendLog(line)
                    }
                }
            }
        }

        Thread {
            val rc = try {
                UntruncNative.run(args.toTypedArray(), listener)
            } catch (t: Throwable) {
                runOnUiThread { appendLog("Erro: $t") }
                -999
            } finally {
                try { pfdOk.close() } catch (_: IOException) { }
                try { pfdBad.close() } catch (_: IOException) { }
            }
            runOnUiThread { onFinished(rc, out) }
        }.start()
    }

    private fun onFinished(rc: Int, out: File) {
        setRunning(false)
        if (rc == 0 && out.exists() && out.length() > 0) {
            progress.progress = 1000
            resultFile = out
            setStatus("Pronto! Escolha onde salvar o vídeo reparado.")
            val base = badName.substringBeforeLast('.', badName)
            val ext = okName.substringAfterLast('.', "mp4")
            val i = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE)
                type = "video/*"
                putExtra(Intent.EXTRA_TITLE, "${base}_fixed.$ext")
            }
            @Suppress("DEPRECATION")
            startActivityForResult(i, REQ_SAVE)
        } else {
            val why = when {
                rc < 0 -> "o processo foi encerrado (código $rc)"
                rc != 0 -> "untrunc terminou com erro (código $rc)"
                else -> "nenhum arquivo foi gerado"
            }
            setStatus("Falhou: $why. Veja o log abaixo.")
            File(cacheDir, "work").deleteRecursively()
        }
    }

    private fun saveResult(dest: Uri) {
        val src = resultFile ?: return
        setStatus("Salvando…")
        btnRepair.isEnabled = false
        Thread {
            var err: String? = null
            try {
                contentResolver.openOutputStream(dest, "wt")!!.use { os ->
                    src.inputStream().use { it.copyTo(os, 1 shl 20) }
                }
            } catch (e: Exception) {
                err = e.message ?: e.toString()
            }
            runOnUiThread {
                if (err == null) {
                    setStatus("Salvo com sucesso (${src.length() shr 20} MB).")
                    Toast.makeText(this, "Vídeo salvo!", Toast.LENGTH_LONG).show()
                    File(cacheDir, "work").deleteRecursively()
                    resultFile = null
                } else {
                    setStatus("Erro ao salvar: $err")
                }
                btnRepair.isEnabled = okUri != null && badUri != null
            }
        }.start()
    }

    override fun onDestroy() {
        if (isFinishing) UntruncNative.cancel()
        super.onDestroy()
    }
}
