package com.untrunc.android

/** Ponte para o untrunc (C++) compilado via NDK. */
object UntruncNative {
    init {
        System.loadLibrary("untrunc_jni")
    }

    interface Listener {
        /** Chamado (na thread que chamou [run]) a cada linha de saída do untrunc. */
        fun onLine(line: String)
    }

    /**
     * Executa o untrunc com [args] (os mesmos argumentos da linha de comando, sem o nome do programa).
     * Arquivos podem ser passados como "fd:<N>". Retorna o código de saída (negativo = sinal/erro).
     */
    @JvmStatic external fun run(args: Array<String>, listener: Listener): Int

    @JvmStatic external fun cancel()

    @JvmStatic external fun version(): String
}
